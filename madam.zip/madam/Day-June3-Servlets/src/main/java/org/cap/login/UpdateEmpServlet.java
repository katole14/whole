package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.login.pojo.Employee;
import org.cap.login.service.LoginService;
import org.cap.login.service.LoginServiceImpl;

/**
 * Servlet implementation class UpdateEmpServlet
 */
public class UpdateEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		int empId=Integer.parseInt(request.getParameter("employeeId"));
		String compEmail=getServletContext().getInitParameter("companyEmail");
		String complEmail=getServletConfig().getInitParameter("feedbckEmail");
		
		

		HttpSession session=request.getSession(true);
		String userName=(String)session.getAttribute("uname");
		
		
		LoginService loginService=new LoginServiceImpl();
		Employee emp=loginService.searchEmployee(empId);
		
		out.println("<html><head><title>UpdateEmployee</title></head>"
				+ "<body>"
				+ "<form method='post' action='UpdateEmployeeServlet' >");
		
		out.println("<h1 align='center'>Update Emplyee</h1><hr>");	
		
		out.println("<div style='margin-left:400px;'><b>Hello! <span>"+userName+" </span></b></div>");
		
		
		
		Cookie[] cookies=request.getCookies();
		for(Cookie ck:cookies)
			out.println(ck.getName() + "-->" + ck.getValue() + "<br>");
		
		out.println("<table style='margin-left:200px;border:1px solid black;'>"
				+ "<tr>"
				+ "<td>Employee Id</td>"
				+ "<td>"+emp.getEmpId()+"</td>"
						+ "<input type='hidden' name='employId' value='"+emp.getEmpId() +"'>" 
				+ "</tr>"
				+ "<tr>"
				+ "<td>FirstName</td>"
				+ "<td><input type='text' name='fname' value='" + emp.getFirstName()+"' size='20'>"
				+ "</tr>"
				+ "<tr>"
				+ "<td></td>"
				+ "<td><input type='submit' name='update' value='Update'>"
				+ "</tr>");
		
		
				
				
				out.println( "</table>"
						+ ""
						+ ""
						+ ""
						+ ""
						+ "<h2>Your Complaints are here: "+ complEmail+"</h2>"
						
						+ "<div style='margin-left:400px;font-weight:bold;'> Company : <i>"+ compEmail+"</i></div>"
						+ "</form></body></html>");
		
		
		
		
	
	}

}
