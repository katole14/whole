package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.login.pojo.Employee;
import org.cap.login.service.LoginService;
import org.cap.login.service.LoginServiceImpl;

import com.google.gson.Gson;


public class JSONListAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		
		PrintWriter out=response.getWriter();
		
		LoginService loginService=new LoginServiceImpl();
		List<Employee> employees=loginService.getAllEmployees();
		
		
		Gson myJson=new Gson();
		
		String empjson=myJson.toJson(employees);
		/*for(Employee emp:employees){
		myJson.toJson(emp);
		}*/
		
		out.println(empjson);
		
	}

}
