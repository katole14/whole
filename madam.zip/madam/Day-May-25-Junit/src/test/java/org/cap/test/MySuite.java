package org.cap.test;

import org.junit.Test;
import org.junit.experimental.categories.Categories;
import org.junit.experimental.categories.Categories.ExcludeCategory;
import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import static org.junit.Assert.*;

@RunWith(Categories.class)
@IncludeCategory(GoodTestCategories.class)
@ExcludeCategory(BadTestCategories.class)
@SuiteClasses({ MyTestCases.class, TrackingServiceTestCase.class })
public class MySuite {
	
/*	@Test
	public void myTest(){
		assertEquals(30, 30);
	}*/

}
