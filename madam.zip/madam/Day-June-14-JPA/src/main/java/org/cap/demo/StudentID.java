package org.cap.demo;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class StudentID implements Serializable {
	
	private int studNo;
	private int courseNo;
	
	public StudentID(){}
	
	public StudentID(int studNo, int courseNo) {
		super();
		this.studNo = studNo;
		this.courseNo = courseNo;
	}
	public int getStudNo() {
		return studNo;
	}
	public void setStudNo(int studNo) {
		this.studNo = studNo;
	}
	public int getCourseNo() {
		return courseNo;
	}
	public void setCourseNo(int courseNo) {
		this.courseNo = courseNo;
	}
	@Override
	public String toString() {
		return "StudentID [studNo=" + studNo + ", courseNo=" + courseNo + "]";
	}
	
	

}
