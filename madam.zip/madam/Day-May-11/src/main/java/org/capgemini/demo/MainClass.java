package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		try{
			Demo_Exception obj=new Demo_Exception();
			obj.calculate();
		}catch(ArithmeticException ex){
			System.out.println("Error: " + ex.getMessage());
		}
		
		System.out.println("Program Completed");
	}

}
