package org.cap.demo;

import java.util.Date;

public class Employee {

	private int empId;
	private String kinId;
	private Date empDob;
	private Date empDoj;
	
	
	
	
	
	
	public Date getEmpDob() {
		return empDob;
	}

	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}

	public Date getEmpDoj() {
		return empDoj;
	}

	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}

	public String getKinId() {
		return kinId;
	}

	public void setKinId(String kinId) {
		this.kinId = kinId;
	}

	//getter Method
	public int getEmpId(){
		return this.empId;
	}
	
	//Setter
	public void setEmpId(int empId){
		this.empId=empId;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", kinId=" + kinId + ", empDob=" + empDob + ", empDoj=" + empDoj + "]";
	}


	
}
