package org.capgemini.test;

public class MainClasss {

	
	final float PI=3.14f;
	
	public void show(){
		System.out.println(PI);
	}
	
	public static void main(String[] args) {
		
		
		Static_Class obj=new Static_Class();
		
		Static_Class.Inner_Class stat_obj=new Static_Class.Inner_Class();
		
		stat_obj.show(12);
		
		MainClasss classs=new MainClasss();
		classs.show();
		
		
	}

}
