package org.capgemini.test;

import static org.capgemini.demo.StaticDemo.*;
import  org.capgemini.demo.Sample;
public class TestClass {

	public static void main(String[] args) {
		//StaticDemo obj=new StaticDemo();
		//obj.non_Static_method();
		Sample.show();

		System.out.println(count);
	}

}
