package org.capgemini.test;

public class Child extends Static_Class {

}
