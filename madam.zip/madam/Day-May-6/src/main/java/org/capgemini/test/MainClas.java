package org.capgemini.test;

public class MainClas {

	public static void main(String[] args) {
		//Child_Class obj=new Child_Class();
		Abs_Classs obj=new Child_Class();
		obj.info();
		
		obj.parent_Method();
		//obj.child_Method();

	}

}
