package org.capgemini.test;

public abstract class Abs_Classs {
	
	public void show(){
		
	}
	
	public Abs_Classs(){
		System.out.println("Abstract Class Constructor");
	}
	
	
	public void parent_Method() {
		
		System.out.println("parent_Method");
	}
	abstract public void info();

}
