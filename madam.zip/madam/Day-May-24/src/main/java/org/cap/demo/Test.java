package org.cap.demo;

public class Test {

	public static void main(String[] args) {
		PrintName t1=new PrintName("Capgemini");
		t1.start();

	}

}
