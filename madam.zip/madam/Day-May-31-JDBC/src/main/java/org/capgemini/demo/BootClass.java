package org.capgemini.demo;

public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction ui=new UserInteraction();
		EmployeeDao empDao=new EmployeeDaoImpl();
		
		
		Employee emp=ui.getEmployee();
		int count=empDao.addEmployee(emp);
		System.out.println(ui.printMessage(count));
		
	}

}
