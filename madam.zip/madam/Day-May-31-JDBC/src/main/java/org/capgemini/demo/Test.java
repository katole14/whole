package org.capgemini.demo;

public class Test implements Runnable{
    public static void main(String[] args) throws InterruptedException{
          Thread a = new Thread(new Test());
          a.start();
          System.out.print("Begin");
          a.join();
          System.out.print("End");
    }
  
    public void run(){
          System.out.print("Run");
    }
}