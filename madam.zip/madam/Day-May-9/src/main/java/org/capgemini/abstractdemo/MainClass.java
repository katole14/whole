package org.capgemini.abstractdemo;

public class MainClass {

	public static void main(String[] args) {
		
		Shape circle=new Circle();
		circle.draw();
		
		//Anonymous
		Shape triangle=new Shape() {
			
			@Override
			public void draw() {
				System.out.println("Draw - Triangle");
				
			}
		};

		
		
		triangle.draw();
	}

}
