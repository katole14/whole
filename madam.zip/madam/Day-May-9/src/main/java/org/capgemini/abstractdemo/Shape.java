package org.capgemini.abstractdemo;

abstract public class Shape {
	
	private int count=100;
	
	abstract public void draw();
	
	public void show(){
		System.out.println("Shape Class Show Method");
	}

}
