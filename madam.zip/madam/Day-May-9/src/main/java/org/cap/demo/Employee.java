package org.cap.demo;

import java.util.Scanner;

public abstract class Employee {
	
	private int empId;
	private String firstName;
	private String lastName;
	
	public Employee(){}
	
	public Employee(int empId,String firstName,String lastName){
		this.empId=empId;
		this.firstName=firstName;
		this.lastName=lastName;
	}
	
	
	public void getEmployeeDetails(){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		empId=sc.nextInt();
		System.out.println("Enter Employee FirstName:");
		firstName=sc.next();
		
		System.out.println("Enter Employee LAstNAme:");
		lastName=sc.next();
	}
	
	public void printEmployeeDetails(){
		System.out.println("\n\nEmp Id: " + empId +"\nFirstName:" + firstName +
				"\nLastName :" + lastName + "\nSalary:" +calculateSalary());
		
		
	}
	
	 abstract double calculateSalary(); 

}
