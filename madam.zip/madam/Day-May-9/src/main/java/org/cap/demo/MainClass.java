package org.cap.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		Employee emp=null;
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("1.Weekly Salary Employee");
		System.out.println("2.Monthly Salary Employee");
		System.out.println("Enter your Choice:");
		int choice=sc.nextInt();
		
		if(choice==1){
			emp=new WeeklySalaryEmployee();
			
		}else if(choice==2){
			emp=new MonthlySalaryEmployee(12,"Tom","Jerry",29,1200);
		}else{
			System.out.println("Invalid input");
			System.exit(0);
		}
		//emp.getEmployeeDetails();
		emp.printEmployeeDetails();
		
		
		
	}

}
