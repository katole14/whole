package org.cap.enumsdemo;



public class MainClass {

	public static void main(String[] args) {
		Employee employee=new Employee(1, "Tom", 2300, Month.JUN);
		
		
		Customer cust=new Customer();
		
		CustomerType ctype=CustomerType.DIAMOND;
		
		employee.printEmployee();
		
		
		for ( Month month  : Month.values())
			System.out.println(month + " -" + month.getValue());

	}

}
