package amstrong;

public class Test {
	public static void main(String[] args) {
		AmstrongNo an=new AmstrongNo();
		an.findAmstrongNo();
	}

}
