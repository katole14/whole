package amstrong;

public class AmstrongNo {
	public void findAmstrongNo() {
		int sum = 0, n = 0;
		System.out.println("-----The Amstrong No Is--------");

		for (int j = 1; j <= 1000; j++) {
			int i = j;
			while (i > 0) {

				n = i % 10;
				i = i / 10;
				sum = sum + (n * n * n);

			}

			if (sum == j) {

				System.out.println(j);

			}
			sum = 0;
		}
	}

}
