package pattern;

public class UserTest {
	public static void main(String[] args) {
		PatternLogic plogic=new PatternLogic();
		plogic.printmsg();
		
		
		
	}
	

}
