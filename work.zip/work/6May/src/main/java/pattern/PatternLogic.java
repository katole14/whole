package pattern;
import java.util.Scanner;
public class PatternLogic {
	

	
	void printmsg() {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the number");
		String a = scan.next();
		switch (a.charAt(0)) {
		case '0': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 5 || j == 1 || j == 5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '1': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (j == 3 || i == 5 || i == 2 && j == 2 || i == 3 && j == 1) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '2': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 3 || i == 5 || j == 5 && i <= 3 || j == 1 && i >= 3) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '3': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 3 || i == 5 || j == 5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '4': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 3 || j == 3 || i == 2 && j == 2) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '5': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 3 || i == 5 || i == 2 && j == 1 || i == 4 && j == 5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '6': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 3 || i == 5 || j == 1 || i == 4 && j == 5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '7': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || j == 5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '8': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 3 || i == 5 || j == 1 || j == 5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		case '9': {
			for (int i = 1; i <= 5; i++) {
				for (int j = 1; j <= 5; j++) {
					if (i == 1 || i == 3 || j == 5 || i == 2 && j == 1 || i==5) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
			break;
		default:
			System.out.println("entered value is wrong");

		}

	}
	}


 
