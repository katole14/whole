package serise;

public class test {
public static void main(String[] args) {
	
	
	
	Fabonacci fs=new Fabonacci();
	fs.find();
}
}
