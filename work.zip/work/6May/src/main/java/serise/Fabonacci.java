package serise;

import java.util.Scanner;

public class Fabonacci {
	public void find(){
		int a=0,b=1,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter no upto u want fabonacci serise");
		int count=sc.nextInt();
		System.out.println("----Fabonacci Serise is---------");
		
		for(int i=0;i<=count;i++){
			
		c=a+b;
		a=b;
		b=c;
			System.out.print(c+" ");
		}
		
		
		
	}

}
