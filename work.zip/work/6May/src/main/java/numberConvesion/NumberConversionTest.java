package numberConvesion;

public class NumberConversionTest {
	
	
	public static void main(String[] args) {
		
		NumberToWord conversion=new NumberToWord();
		
		conversion.conversionToWord();
		
	}
	

}
