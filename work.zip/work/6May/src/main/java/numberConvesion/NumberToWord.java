package numberConvesion;

import java.util.Scanner;

public class NumberToWord {
	
	
	
	public void conversionToWord(){
		int reverse_no=0 ,reverse_no1=0;
		System.out.println("Enter the 4 digit no whish you want to convert into word");
		Scanner sc= new Scanner(System.in);
		int user_no=sc.nextInt();
		
		   while( user_no != 0 )
	      {
			 reverse_no = reverse_no * 10;
			 reverse_no = reverse_no + user_no%10;
			 user_no = user_no/10;
	      }
	
		   System.out.println(reverse_no);
		   
		   
		   for(int i=1;i<=4;i++)
			{
			   reverse_no=reverse_no%10;
			   user_no=user_no/10;
				switch (reverse_no) {
				case 0:System.out.print("Zero\t");		
					break;
					
				case 1:System.out.print("One\t");
				
				break;
				case 2:if(i==3)
					System.out.print("Twenty\t");
				else
					System.out.print("Two\t");
				
				break;
				case 3:if(i==3)
					System.out.print("Thirty\t");
				else
					System.out.print("Three\t");
				
				break;
				case 4:if(i==3)
					System.out.print("Fourty\t");
				else
					System.out.print("Four\t");
				
				break;
				case 5:if(i==3)
					System.out.print("Fifty\t");
				else
					System.out.print("Five\t");
				
				break;
				case 6:if(i==3)
					System.out.print("Sixty\t");
				else
					System.out.print("Six\t");
				
				break;
				case 7:if(i==3)
					System.out.print("Seventy\t");
				else
					System.out.print("Seven\t");
				
				break;
				case 8:if(i==3)
					System.out.print("Eighty\t");
				else
					System.out.print("Eight\t");
				
				break;
				case 9:if(i==3)
					System.out.print("Ninty\t");
				else
					System.out.print("Nine\t");
				
				break;
			}
				
				if(i==1)
				System.out.print("Thousand\t");
				else if(i==2)
					System.out.print("Hundred and\t");
				else if(i==4)
					System.out.print("only\t");  
	

}
}}