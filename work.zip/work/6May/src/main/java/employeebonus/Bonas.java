package employeebonus;

import java.util.Scanner;

public class Bonas {
	
	
	public void calculate(){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("please Enter Your Name");
		String name=sc.next();
		System.out.println("Please Enter your Salary In Terms Of Laks");
		int salary=sc.nextInt();
		
		if(salary>20){
			
			
			float a=salary*15;
			float bon=a/100;
		   System.out.println(name);
           System.out.println("Your bonus is"+bon+"laks");			
			
		}else if(salary >10 && salary<20){
			
			
			float b=salary*20;
			float bon1=b/100;
			System.out.println(name);
			System.out.println("Your bonus is"+bon1+"laks");
			
			
		}else if(salary >5 && salary<10){
			
			
			float c=salary*25;
			float bon2=c/100;
			System.out.println(name);
			System.out.println("Your bonus is"+bon2+"laks");
			
			
		}else if(salary <5){
			
			
			float d=salary*30;
			float bon3=d/100;
			System.out.println(name);
			System.out.println("Your bonus is"+bon3+"laks");
			
			
		}
		
		
		
		
		
		
		
	}
	
	

}
