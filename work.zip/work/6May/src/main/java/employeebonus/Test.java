package employeebonus;

public class Test {
	
	
	public static void main(String[] args) {
		
		
		Bonas bs=new Bonas();
		bs.calculate();
		
	}

}
