package digitnumber;

public class Word {
	
	
	public void convert(){
		
		System.out.println();
		
		
		
		
		
	}

}
