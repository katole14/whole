package bigno;

import java.util.Scanner;

public class BigNoAmong {
	
	public void finder(){
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter three No");
		
	     int A=	sc.nextInt();
	     int B=	sc.nextInt();
	     int C=	sc.nextInt();
	     
	     if(A>B && A>C)
	     {
	    	 
	    		 System.out.println("Biger No is"+A);
	    		 
	    	 
	     }else if(B>A && B>C){
	    	 
	    	 System.out.println("Biger No is"+B);
	    	 
	    	 
	     }else if(C>A && C>B){
	    	 
	    	 System.out.println("Biger No is"+C);
	    	 
	     }
		
		
		
		
		
	}
	
	

}
