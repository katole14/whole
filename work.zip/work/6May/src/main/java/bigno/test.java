package bigno;

import java.util.Scanner;

public class test {
	
	
	public static void main(String[] args) {
		BigNoAmong Big=new BigNoAmong();
		Big.finder();
		
	     
	     
		
	}

}

