
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class MainClass {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Employee.class);
		config.configure();
		
		SessionFactory sessfactory=config.buildSessionFactory();
		Session session=sessfactory.openSession();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter your choice");
		System.out.println("1 creat employee");
		System.out.println("2 view employee");
		System.out.println("3 delete employee");
		System.out.println("4 update employee");
		int choice=sc.nextInt();
   switch(choice)	{
   
   case 1:
   case 2:
   
   
   
   
   
   
   
   
   }	
		
		
		
		session.getTransaction().begin();
		
		
		
		
		
		
		
		session.getTransaction().commit();
		session.close();
		

	}

}
