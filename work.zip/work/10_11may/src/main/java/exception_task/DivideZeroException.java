package exception_task;

public class DivideZeroException {
int num1=100,num2=0,num3;
void calculate(){
	try{
	num3=num1/num2;
	System.out.println("Answer is: "+num3);
	}catch(ArithmeticException e){
		System.out.println("Error mesage: "+e.getMessage());
	}
}
}
