package exception_task;

import java.util.Scanner;

public class AccountMainClass {
public static void main(String[] args) {
	
	
	Account acc=new Account();
	boolean flag=false;
	acc.setAccountId(111);
	acc.setAccountName("chaitanya");
	acc.setAccountType("saving");
	acc.setOpeningDate("14/11/93");
	Scanner sc=new Scanner(System.in);
	System.out.println("please enter amount u want to deposite within range 500-1000");
	double amount=sc.nextDouble();
	if(amount>500 && amount<100){
		
		acc.setDepositAmt(amount);
	}
	else{
		
		
		throw new AmountInvalidException("Amount not in range");
		
	}

	
	
}
}
