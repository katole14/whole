package exception_task;

public class DivideMain {
public static void main(String args[]){
	 DivideZeroException d=new DivideZeroException();
	d.calculate();;
	System.out.println("Rest of the Code Executed");
}
}