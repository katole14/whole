package exception_task;

public class AmountInvalidException extends RuntimeException{
	
	public AmountInvalidException(String msg){
		
		super(msg);
		
		
	}

}
