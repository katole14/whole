package assr;

import java.util.Scanner;





public class Assert_Demo {
	
	
		
	public void verifySalary(){
	double salary;
	Scanner sc=new Scanner(System.in);
System.out.println("Enter your salary");
salary=sc.nextDouble();
	assert salary <= 2000:"Salary should be less than 2000";
	}

}
