package assr;

public class MainClass {
public static void main(String[] args) {
	Assert_Demo dem=new Assert_Demo();
	dem.verifySalary();
}
}
