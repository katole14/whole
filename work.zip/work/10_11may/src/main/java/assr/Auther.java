package assr;

import java.lang.annotation.*;

@Target({ElementType.TYPE,ElementType.METHOD,ElementType.CONSTRUCTOR})
@Retention(RetentionPolicy.CLASS)
public @interface Auther {
	
	String authorName();
	String publish() default "tata"; 
	double price();

}
