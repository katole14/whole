package employeeValidation;

import java.util.Date;

public class Employee {

	private String empId ,kinId ,firstName,lastName ,age,salary,address;
	private Date empDOB,empDOJ;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getKinId() {
		return kinId;
	}

	public void setKinId(String kinId) {
		this.kinId = kinId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	

	public Date getEmpDOB() {
		return empDOB;
	}

	public void setEmpDOB(Date empDOB) {
		this.empDOB = empDOB;
	}

	public Date getEmpDOJ() {
		return empDOJ;
	}

	public void setEmpDOJ(Date dOJ) {
		this.empDOJ = dOJ;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", kinId=" + kinId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", age=" + age + ", salary=" + salary + ", address=" + address + ", empDOB=" + empDOB + ", empDOJ="
				+ empDOJ + "]";
	}

	
	
	
	
}
