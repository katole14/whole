package employeeValidation;

public class MainClass {
	public static void main(String[] args) {
		UserInteraction intersation = new UserInteraction();
	

		Employee emp1 = intersation.getEmployee();
		System.out.println(emp1);
	}
}
