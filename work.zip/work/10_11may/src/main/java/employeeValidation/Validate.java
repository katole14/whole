package employeeValidation;

public class Validate {
	public static boolean validateEmpId(String empId) {
		return empId.matches("\\d{5}");

	}

	public static boolean validatekinId(String kinId) {
		return kinId.matches("\\d{5}_(FS|TS|IN|fs|ts|in)");
	}

	public static boolean validatefName(String firstName) {
		return firstName.matches("[A-Z][a-z]*");
	}

	public static boolean validatelName(String lastName) {
		return lastName.matches("[A-Z][a-z]*");
	}

	public static boolean validateage(String age) {
		return age.matches("1[9]|2[0-9]|3[0-9]|4[0-9]|5[0-9]|6[0-9]|7[0-9]|8[0-9]|9[0-9]|100*");

	}

	public static boolean validateEmpDOB(String empDOB) {
		return empDOB.matches("[0-3][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-"
				+ "[12][7890]\\d{2}");
	}

	public static boolean validatAddress(String address) {
		return address.matches("[A-Z]a-z");
	}
	public static boolean validatAddresssalary(String salary) {
		return salary.matches("[^01][0-9][0-9][0-9]|[0-9][0-9][0-9][0-9][0-9]|[1-4][0-9][0-9][0-9][0-9][0-9]|[5][0][0][0][0][0]");
}
}