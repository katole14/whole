package employeeValidation;

import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
	public Employee getEmployee() {

		Employee emp = new Employee();
		int employeeId;
		boolean flag = false;
		String eid, empKinId, fName, lname, Age, sALARY, DOB, DOJ, addr;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("enter emp id");
			eid = sc.next();
		
				flag = Validate.validateEmpId(eid);
				if (!flag)
				System.out.println("INvalid EmployeeId! ID should be 5 digit!");

		} while (!flag);
		emp.setEmpId(eid);

		do {
			flag = false;
			System.out.println("enter emp KinId");
			empKinId = sc.next();
			
				flag = Validate.validatekinId(empKinId);
				if (!flag)
				System.out.println("INvalid Employee KinId! ID should be 5 digit then _ then FS|TS|IN|fs|ts|in !");

		} while (!flag);
		emp.setKinId(empKinId);
		do {
			flag = false;
			System.out.println("enter your first Name");
			fName = sc.next();
			
				flag = Validate.validatefName(fName);
				if (!flag)
				System.out.println(
						"INvalid Employee first name!name should be first initial capital letter followed by other small letters no space no number !");

		} while (!flag);
		emp.setFirstName(fName);
		do {
			flag = false;
			System.out.println("enter your last Name");
			lname = sc.next();
			
				flag = Validate.validatelName(lname);
				if (!flag)
				System.out.println(
						"INvalid Employee last name!Last should be letters with space no number & special character !");

		} while (!flag);
		emp.setLastName(lname);
		do {
			flag = false;
			System.out.println("enter emp age");
			Age = sc.next();
			
				flag = Validate.validateage(Age);
				if (!flag)
				System.out.println("INvalid Employee age! age should be grater than 18years");

		} while (!flag);
		emp.setAge(Age);
		do {
			flag = false;
			System.out.println("enter emp sALARY");
			sALARY = sc.next();
		
				flag = Validate.validatAddresssalary(sALARY);
				if (!flag)
				System.out.println("INvalid Employee sALARY! sALARY should be in the range 2000-500000");

		} while (!flag);
		emp.setSalary(sALARY);
		do {
			flag = false;
			System.out.println("enter emp DOB");
			DOB = sc.next();
			
				flag = Validate.validateage(DOB);
				
				
				try{
				if (!flag)
					throw new InvalidDateException("Date format should be dd-mm-yy");
				}catch(InvalidDateException e){
					System.out.println(e.getMessage());
				}
		
				}while (!flag);
		emp.setEmpDOB(getDateValue());

		
		do {
			flag = false;
			System.out.println("enter emp DOJ");
			DOJ = sc.next();
			
				flag = Validate.validateage(DOJ);
				if (!flag)
				System.out.println("INvalid Employee DOJ! DOJ should be in the format dd-mmm-yyyy");

		} while (!flag);
		emp.setEmpDOJ(getDateValue());

		do {
			flag = false;
			System.out.println("enter emp addr");
			addr = sc.next();
			
				flag = Validate.validateage(addr);
				if (!flag)
				System.out.println("INvalid Employee addr! addr should be in the format contains [_-,;] words");

		} while (!flag);
		emp.setAddress(addr);
		
		emp.setAddress(addr);

		

		return emp;
		
	}

	
	public Date getDateValue(){
		String empDob;
		Scanner sc=new Scanner(System.in);
		boolean flag=false;
		
		do{
		
		empDob=sc.next();
		flag=Validate.validateEmpDOB(empDob);
		
			if(!flag)
				System.out.println("DOB should be in the format dd-mmm-yyyy");
		
		}while(!flag);
		
		
		Date empdb=new Date(empDob);
		
		return empdb;
	}
	
}
