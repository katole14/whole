package org.cap.capstore.dao;

import java.util.List;

import org.cap.capstore.dto.OrderStatus;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class CapStoreDaoImplementation implements CapStoreDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<OrderStatus> getDeliveryDetails() {
		 return sessionFactory.getCurrentSession().createQuery("from OrderStatus").list();

}
}