package org.cap.capstore.dto;

public class CouponAssigned {

	private Customer customer;
	private Coupon coupon;
	
	public CouponAssigned() {
		// TODO Auto-generated constructor stub
	}

	public CouponAssigned(Customer customer, Coupon coupon) {
		super();
		this.customer = customer;
		this.coupon = coupon;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Coupon getCoupon() {
		return coupon;
	}

	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}

	@Override
	public String toString() {
		return "CouponAssigned [customer=" + customer + ", coupon=" + coupon + "]";
	}
}
