package org.cap.capstore.dto;

public class Product {
	private int productId;
	private String productName;
	private Category category;
	private int stock;
	private int viewCount;	
	private Merchant merchant;
	private float rating;
	private Feedback feedback;
	private double price;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, Category category, int stock, int viewCount, Merchant merchant,
			float rating, Feedback feedback, double price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.category = category;
		this.stock = stock;
		this.viewCount = viewCount;
		this.merchant = merchant;
		this.rating = rating;
		this.feedback = feedback;
		this.price = price;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getViewCount() {
		return viewCount;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public Feedback getFeedback() {
		return feedback;
	}

	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category
				+ ", stock=" + stock + ", viewCount=" + viewCount + ", merchant=" + merchant + ", rating=" + rating
				+ ", feedback=" + feedback + ", price=" + price + "]";
	}
	

}
