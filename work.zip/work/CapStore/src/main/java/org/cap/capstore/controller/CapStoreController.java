package org.cap.capstore.controller;

import org.cap.capstore.dto.OrderStatus;
import org.cap.capstore.service.CapStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CapStoreController {
	
	@Autowired
	private CapStoreService capstoreservice;

	@RequestMapping("/deliveryDetails")
	public String showDeliveryDetails(ModelMap map) {
		map.put("orderstatus", capstoreservice.getDeliveryDetails());
		return "deliveringproduct";
	}

}
