package org.cap.capstore.dao;

import java.util.List;

import org.cap.capstore.dto.OrderStatus;


public interface CapStoreDao {
	public List<OrderStatus>  getDeliveryDetails() ;

}
