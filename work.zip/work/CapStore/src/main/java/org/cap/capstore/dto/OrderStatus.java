package org.cap.capstore.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderStatus {
	@Id
	private int statusId;
	private String deliveryStatus;
    private String shippingVia;
    private Date expectedDeliveryDate;
    public OrderStatus() {
		
	}
    
	public OrderStatus(int statusId, String deliveryStatus, String shippingVia, Date expectedDeliveryDate) {
		super();
		this.statusId = statusId;
		this.deliveryStatus = deliveryStatus;
		this.shippingVia = shippingVia;
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public String getShippingVia() {
		return shippingVia;
	}
	public void setShippingVia(String shippingVia) {
		this.shippingVia = shippingVia;
	}
	public Date getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}
	public void setExpectedDeliveryDate(Date expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	@Override
	public String toString() {
		return "Status [statusId=" + statusId + ", deliveryStatus=" + deliveryStatus + ", shippingVia=" + shippingVia
				+ ", expectedDeliveryDate=" + expectedDeliveryDate + "]";
	}
	

}
