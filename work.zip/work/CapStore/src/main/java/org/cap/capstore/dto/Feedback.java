package org.cap.capstore.dto;

public class Feedback {

	private int feedbackId;
	private String feedbackText;
	private String description;

	public Feedback() {

	}

	public Feedback(int feedbackId, String feedbackText, String description) {
		super();
		this.feedbackId = feedbackId;
		this.feedbackText = feedbackText;
		this.description = description;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getText() {
		return feedbackText;
	}

	public void setText(String feedbackText) {
		this.feedbackText = feedbackText;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", feedbackText=" + feedbackText + ", description=" + description
				+ "]";
	}

}
