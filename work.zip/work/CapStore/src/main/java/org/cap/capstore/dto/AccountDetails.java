package org.cap.capstore.dto;

import java.util.Date;

public class AccountDetails {

	private Customer customer;
	private String cardNumber;
	private Date expiryDate;
	private String cardOnName;
	private int cvv;

	public AccountDetails() {

	}

	public AccountDetails(Customer customer, String cardNumber, Date expiryDate, String cardOnName, int cvv) {
		super();
		this.customer = customer;
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
		this.cardOnName = cardOnName;
		this.cvv = cvv;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getCardOnName() {
		return cardOnName;
	}

	public void setCardOnName(String cardOnName) {
		this.cardOnName = cardOnName;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "AccountDetails [customer=" + customer + ", cardNumber=" + cardNumber + ", expiryDate=" + expiryDate
				+ ", cardOnName=" + cardOnName + ", cvv=" + cvv + "]";
	}
}
