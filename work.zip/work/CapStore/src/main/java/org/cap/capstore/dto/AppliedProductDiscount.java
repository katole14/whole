package org.cap.capstore.dto;

public class AppliedProductDiscount {
	private Product product;
	private Discount discount;
	
	public AppliedProductDiscount(){
		
	}

	public AppliedProductDiscount(Product product, Discount discount) {
		super();
		this.product = product;
		this.discount = discount;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "AppliedProductDiscount [product=" + product + ", discount=" + discount + "]";
	}
	
	
}
