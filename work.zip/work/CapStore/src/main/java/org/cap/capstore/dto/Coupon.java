package org.cap.capstore.dto;

import java.util.Date;

public class Coupon {

	private int couponId;
	private String couponName;
	private String couponType;
	private double couponOffer;
	private Date validThrough;
	
	public Coupon() {
		// TODO Auto-generated constructor stub
	}

	public Coupon(int couponId, String couponName, String couponType, double couponOffer, Date validThrough) {
		super();
		this.couponId = couponId;
		this.couponName = couponName;
		this.couponType = couponType;
		this.couponOffer = couponOffer;
		this.validThrough = validThrough;
	}

	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public String getCouponType() {
		return couponType;
	}

	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}

	public double getCouponOffer() {
		return couponOffer;
	}

	public void setCouponOffer(double couponOffer) {
		this.couponOffer = couponOffer;
	}

	public Date getValidThrough() {
		return validThrough;
	}

	public void setValidThrough(Date validThrough) {
		this.validThrough = validThrough;
	}

	@Override
	public String toString() {
		return "Coupon [couponId=" + couponId + ", couponName=" + couponName + ", couponType=" + couponType
				+ ", couponOffer=" + couponOffer + ", validThrough=" + validThrough + "]";
	}
	
	

}
