package org.cap.capstore.dto;

import java.util.List;
import java.util.Map;

public class Cart {
	private Customer customer;
	private List<Product> products;
	private Map<Product, Integer> productQuantity; 
	
	public Cart() {
		
	}

	public Cart(Customer customer, List<Product> products, Map<Product, Integer> productQuantity) {
		super();
		this.customer = customer;
		this.products = products;
		this.productQuantity = productQuantity;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Map<Product, Integer> getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(Map<Product, Integer> productQuantity) {
		this.productQuantity = productQuantity;
	}

	@Override
	public String toString() {
		return "Cart [customer=" + customer + ", products=" + products + ", productQuantity=" + productQuantity + "]";
	}
	
	
	

}
