package org.cap.capstore.dto;

public class AppliedCategoryDiscount {
	private Category category;
	private Discount discount;
	
	
	public AppliedCategoryDiscount(){
		
	}


	public AppliedCategoryDiscount(Category category, Discount discount) {
		super();
		this.category = category;
		this.discount = discount;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public Discount getDiscount() {
		return discount;
	}


	public void setDiscount(Discount discount) {
		this.discount = discount;
	}


	@Override
	public String toString() {
		return "AppliedCategoryDiscount [category=" + category + ", discount=" + discount + "]";
	}
	
	

}
