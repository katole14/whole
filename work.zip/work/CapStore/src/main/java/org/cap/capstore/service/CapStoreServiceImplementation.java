
package org.cap.capstore.service;

import java.util.List;

import org.cap.capstore.dao.CapStoreDao;
import org.cap.capstore.dto.Customer;
import org.cap.capstore.dto.OrderStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CapStoreServiceImplementation implements CapStoreService{
	@Autowired
	private CapStoreDao capdao;

	@Transactional
	public List<OrderStatus> getDeliveryDetails() {
		
		return capdao.getDeliveryDetails();
	}

	@Transactional
	public Customer getCustomerAddress() {
		// TODO Auto-generated method stub
		return null;
	}

}
