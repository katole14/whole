package org.cap.capstore.dto;

public class RatingProduct {
	private Category category;
	private Product product;
	private float rating;
	
	
	public RatingProduct(){
		
	}


	public RatingProduct(Category category, Product product, float rating) {
		super();
		this.category = category;
		this.product = product;
		this.rating = rating;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}


	public float getRating() {
		return rating;
	}


	public void setRating(float rating) {
		this.rating = rating;
	}


	@Override
	public String toString() {
		return "RatingProduct [category=" + category + ", product=" + product + ", rating=" + rating + "]";
	}
	
	
	
	
	

}
