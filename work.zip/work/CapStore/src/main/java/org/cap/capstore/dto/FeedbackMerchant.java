package org.cap.capstore.dto;

public class FeedbackMerchant {

	private Feedback feedback;
	private Product product;
	
	public FeedbackMerchant(){
		
	}

	public FeedbackMerchant(Feedback feedback, Product product) {
		super();
		this.feedback = feedback;
		this.product = product;
	}

	public Feedback getFeedback() {
		return feedback;
	}

	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "FeedbackMerchant [feedback=" + feedback + ", product=" + product + "]";
	}

	
	
}
