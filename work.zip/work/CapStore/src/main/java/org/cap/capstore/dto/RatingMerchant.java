package org.cap.capstore.dto;

public class RatingMerchant {
	private Customer customer;
	private Product product;
	private float rating;
	private Merchant merchant;
	
	public RatingMerchant(){
		
	}

	public RatingMerchant(Customer customer, Product product, float rating, Merchant merchant) {
		super();
		this.customer = customer;
		this.product = product;
		this.rating = rating;
		this.merchant = merchant;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	@Override
	public String toString() {
		return "RatingMerchant [customer=" + customer + ", product=" + product + ", rating=" + rating + ", merchant="
				+ merchant + "]";
	}
	
	

}
