package org.cap.capstore.service;

import java.util.List;

import org.cap.capstore.dto.Customer;
import org.cap.capstore.dto.OrderStatus;

public interface CapStoreService {
public List<OrderStatus> getDeliveryDetails();
public Customer getCustomerAddress();

}
