package org.cap.capstore.dto;

import java.util.Date;

public class Discount {
	private int discountId;
	private String discountName;
	private Date validThrough;
	private double percentage;
	
	
	public Discount(){}
	
	public Discount(int discountId, String discountName, Date validThrough, double percentage) {
		super();
		this.discountId = discountId;
		this.discountName = discountName;
		this.validThrough = validThrough;
		this.percentage = percentage;
	}
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public Date getValidThrough() {
		return validThrough;
	}
	public void setValidThrough(Date validThrough) {
		this.validThrough = validThrough;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	
	@Override
	public String toString() {
		return "Discount [discountId=" + discountId + ", discountName=" + discountName + ", validThrough="
				+ validThrough + ", percentage=" + percentage + "]";
	}
	
	

}
