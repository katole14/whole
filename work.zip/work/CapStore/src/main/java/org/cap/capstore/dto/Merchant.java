package org.cap.capstore.dto;

public class Merchant {

	private int merchantID;
	private String name;
	private String email;
	private long phoneNumber;
	private MerchantType merchantType;
	private String address;
	private Feedback feedback;
	private float rating;
	private String userName;
	private String password;
	
	public Merchant() {
		
	}

	public Merchant(int merchantID, String name, String email, long phoneNumber, MerchantType merchantType,
			String address, Feedback feedback, float rating, String userName, String password) {
		super();
		this.merchantID = merchantID;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.merchantType = merchantType;
		this.address = address;
		this.feedback = feedback;
		this.rating = rating;
		this.userName = userName;
		this.password = password;
	}

	public int getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(int merchantID) {
		this.merchantID = merchantID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public MerchantType getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(MerchantType merchantType) {
		this.merchantType = merchantType;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Feedback getFeedback() {
		return feedback;
	}

	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Merchant [merchantID=" + merchantID + ", name=" + name + ", email=" + email + ", phoneNumber="
				+ phoneNumber + ", merchantType=" + merchantType + ", address=" + address + ", feedback=" + feedback
				+ ", rating=" + rating + ", userName=" + userName + ", password=" + password + "]";
	}
	
	

	

}
