package thread;

public class MainClass {
	
	public static void main(String[] args) {
		
		
		MyThread t1=new MyThread(5);
		MyThread t2=new MyThread(10);
		MyThread t3=new MyThread(15);
		
		t1.start();
		
	}

}
