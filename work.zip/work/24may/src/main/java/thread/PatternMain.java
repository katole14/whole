package thread;

public class PatternMain {

	public static void main(String[] args) {
		
		PatternThread pthread=new PatternThread("capgemini");
		PatternThread pthread1=new PatternThread("chaitanya");
		PatternThread pthread2=new PatternThread("birthday");
			
		
		
		.start();
	    .start();
		.start();

}
}