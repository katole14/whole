package thread;

public class PatternThread extends Thread {

	String name=null;
	public PatternThread(String name){
		
		this.name=name;
		
	}
	
	public void name_print(){
		
		for(int i=0;i<=name.length();i++){
			
			System.out.println(name.substring(0, i));
			
		}
		
	
		
	}
	@Override
	public void run(){
		
		name_print();
		
	}
}
