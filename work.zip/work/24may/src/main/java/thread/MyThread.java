package thread;

public class MyThread extends Thread {
	private int num2;
	
	
	
	
	public MyThread(int num2) {
		this.num2=num2;
	}


	@Override
	public void run(){
		
		for(int i=0;i<=15;i++){
			System.out.println(i+"*"+num2 +"="+(i*num2));
		}
		
		
		
		
	}

}
