package objectio_demo;

public class AddressPojo {
	
	int door_no;
	String streat_name;
	String city;
	String state;
	public int getDoor_no() {
		return door_no;
	}
	public void setDoor_no(int door_no) {
		this.door_no = door_no;
	}
	public String getStreat_name() {
		return streat_name;
	}
	public void setStreat_name(String streat_name) {
		this.streat_name = streat_name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "AddressPojo [door_no=" + door_no + ", streat_name=" + streat_name + ", city=" + city + ", state="
				+ state + "]";
	}
	

}
