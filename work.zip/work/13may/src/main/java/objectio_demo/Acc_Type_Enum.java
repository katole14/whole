package objectio_demo;

public enum Acc_Type_Enum {
	Saving,Current;

}
