package objectio_demo;

public class MainClass {
	public static void main(String[] args) {
		UserInteraction inter=new UserInteraction();
		inter.menu();
		
	}

}
