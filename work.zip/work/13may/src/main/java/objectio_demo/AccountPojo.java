package objectio_demo;

import java.io.Serializable;

public class AccountPojo implements Serializable {
	int account_no;
	String fname;
	String lname;
	Acc_Type_Enum acc_type;
	String open_date;
	AddressPojo addr;

	public AddressPojo getAddr() {
		return addr;
	}

	public void setAddr(AddressPojo addr) {
		this.addr = addr;
	}

	public int getAccount_no() {
		return account_no;
	}

	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	

	public Acc_Type_Enum getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(Acc_Type_Enum acc_type) {
		this.acc_type = acc_type;
	}

	public String getOpen_date() {
		return open_date;
	}

	public void setOpen_date(String open_date) {
		this.open_date = open_date;
	}

	@Override
	public String toString() {
		return "AccountPojo [account_no=" + account_no + ", fname=" + fname + ", lname=" + lname + ", acc_type="
				+ acc_type + ", open_date=" + open_date + ", addr=" + addr + "]";
	}

	
	
	

}
