package objectio_demo;

import java.io.File;

public class Repository {
	
	File file = new File("D:\\chaitanya\\New folder\\input_file.dat");

}
