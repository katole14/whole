package objectio_demo;

import java.util.Scanner;





public class UserInteraction {
	public void menu(){
	int choice;
	AccountDaoImplementation Aacc_imple= new AccountDaoImplementation();
	Scanner sc=new Scanner(System.in);
	do{
	System.out.println("please Select option From Below");
	System.out.println("1 for creat account"+
	"\n2 for read account"+
	"\n3 for view all account"+
	"\n4 for delete account"+
	"\n5 for update account"+
	"\n6 for exit");
	choice=sc.nextInt();
	switch(choice){
	
	case 1:AccountPojo acc =Aacc_imple.creat_account();
	System.out.println(acc);
	break;
	case 2:Aacc_imple.read_account();
	break;
	case 3:Aacc_imple.view_aa_account();
	break;
	case 4:Aacc_imple.delete_account();
	break;
	case 5:Aacc_imple.update_account();
	break;
	
	default : System.out.println("Invalid Input Please Try Again");
	
	
	}
	
	
	
	}while(choice==6);
	}
}
