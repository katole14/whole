package objectio_demo;

public interface AccountDao {
	
	
	public AccountPojo creat_account();
	public void read_account();
	public void update_account();
	public void delete_account();
	public void view_aa_account();
	
	

}
