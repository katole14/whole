package objectio_demo;

import java.io.ObjectOutputStream;
import java.util.Scanner;

public class AccountDaoImplementation implements AccountDao {

	public AccountPojo creat_account() {
		AccountPojo acc_pojo=new AccountPojo();
		AddressPojo addr_pojo=new AddressPojo();
		Scanner sc=new Scanner(System.in);
		int account_no;
		String fname;
		String lname;
		Acc_Type_Enum acc_Type=null;
		String open_date;
		AddressPojo addr;
		int door_no;
		String streat_name;
		String city;
		String state;
		int choice;
		System.out.println("Please Give the Following Details");
		System.out.println("Please Enter 4 digit acc no of your choice");
		acc_pojo.setAccount_no(account_no=sc.nextInt());
		System.out.println("Please Enter First name");
		acc_pojo.setFname(fname=sc.next());
		System.out.println("Please Enter Last Name");
		acc_pojo.setLname(lname=sc.next());
		System.out.println("Please Enter Open date in format dd-mm-yyyy");
		acc_pojo.setOpen_date(open_date=sc.next());
		System.out.println("please enter address First Door no");
		addr_pojo.setDoor_no(door_no=sc.nextInt());
		System.out.println("Streat Name");
		addr_pojo.setStreat_name(streat_name=sc.next());
		System.out.println("city");
		addr_pojo.setCity(city=sc.next());
		System.out.println("State");
		addr_pojo.setState(state=sc.next());
		System.out.println("please select account type"+"\n1-for saving"+"\n2-for current");
		
		switch( choice=sc.nextInt()){
		case 1: acc_Type = Acc_Type_Enum.Saving;
		break;
		case 2: acc_Type = Acc_Type_Enum.Current;
		}
		acc_pojo.setAcc_type(acc_Type);
		acc_pojo.setAddr(addr_pojo);
		
		
		
		
		
		
		
		/*ObjectOutputStream out=null;
		
		out.writeObject(arg0);*/
		
		
		return acc_pojo;
		
		
		
		
	}

	public void read_account() {
		// TODO Auto-generated method stub
		
	}

	public void update_account() {
		// TODO Auto-generated method stub
		
	}

	public void delete_account() {
		// TODO Auto-generated method stub
		
	}

	public void view_aa_account() {
		// TODO Auto-generated method stub
		
	}

}
