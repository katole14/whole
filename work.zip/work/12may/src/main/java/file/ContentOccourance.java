package file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ContentOccourance {
public static void main(String[] args) {
	File file = new File("D:\\chaitanya\\New folder\\input_file.txt");
	FileReader fread=null;
	
	
	int a=0,e=0,i=0,o=0,u=0;
		try {
			fread =new FileReader(file);
			long length=file.length();
			while(length>0){
			int c=fread.read();
			char ch=(char)c;
			switch(Character.toUpperCase(ch)){
			
			
			
			case 'A':
			a++;
			break;
			
			
			case 'E':
				e++;
				break;
			case 'I':
				i++;
				break;
			case 'O':
				o++;
				break;
			case 'U':
				u++;
				break;
			}
				
			length--;
				
			}} catch (FileNotFoundException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} catch (IOException p) {
			// TODO Auto-generated catch block
			p.printStackTrace();
		}finally{
			
			try {
				fread.close();
				
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
		
		System.out.println("Numbers of a="+a+
				"\n Numberof e="+e+
				"\n Number of i="+i+
				"\n Number of o="+o+
				"\n Number og u="+u);
			
			
		
	
}
}
