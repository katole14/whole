package file;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCopy {
	public static void main(String[] args) {
		File file = new File("D:\\chaitanya\\New folder\\input_file.txt");
		File file2 = new File("D:\\chaitanya\\New folder\\output_file.txt");
		FileReader fread = null;
		FileWriter fwrite = null;
		try {
			fread = new FileReader(file);
			fwrite =new FileWriter (file2);
			int c=fread.read();
			
			while (c!=-1) {
				 fwrite.write(c);
				    c = fread.read();
				
				

			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}

		finally {
			try {
				fwrite.close();
				fread.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}
}