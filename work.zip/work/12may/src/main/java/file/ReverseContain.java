package file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseContain {
	public static void main(String[] args) {
		File file = new File("D:\\chaitanya\\New folder\\input_file.txt");
		FileReader fread=null;
		FileWriter fwrite=null;
		
		try {
			fread =new FileReader(file);
			
			long length=file.length();
			String content="";
			String reverse_content="";
			while(length >0){
				int c=fread.read();
				content +=(char)c;
				length--;
				
				
			}
			System.out.println(content);
			fread.close();
			for(int i=content.length()-1;i>=0;i--){
				reverse_content +=content.charAt(i);
			}
			
			System.out.println(reverse_content);
			fwrite=new FileWriter(file,true);
			fwrite.write(reverse_content);
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
