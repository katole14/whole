package lang_demo;

public class TestEmployee {

	public static void main(String[] args) {
		
	
	Employee emp1=new Employee(123, "chaitanya", "katole", 122.2);
	Employee emp2=new Employee(123, "chaitanya", "katole", 122.2);
	
	
	System.out.println(emp1 == emp2);
	System.out.println(emp1.equals(emp2));
	
}}
