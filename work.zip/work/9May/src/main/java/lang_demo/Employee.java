package lang_demo;

public class Employee {


int empid;
String f_name,l_name;
double salary;
public Employee(int empid, String f_name, String l_name, double salary) {
	super();
	this.empid = empid;
	this.f_name = f_name;
	this.l_name = l_name;
	this.salary = salary;
	
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + empid;
	result = prime * result + ((f_name == null) ? 0 : f_name.hashCode());
	result = prime * result + ((l_name == null) ? 0 : l_name.hashCode());
	long temp;
	temp = Double.doubleToLongBits(salary);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Employee other = (Employee) obj;
	if (empid != other.empid)
		return false;
	if (f_name == null) {
		if (other.f_name != null)
			return false;
	} else if (!f_name.equals(other.f_name))
		return false;
	if (l_name == null) {
		if (other.l_name != null)
			return false;
	} else if (!l_name.equals(other.l_name))
		return false;
	if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
		return false;
	return true;
}





}
