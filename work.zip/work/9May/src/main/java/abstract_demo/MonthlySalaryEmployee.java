package abstract_demo;

public class MonthlySalaryEmployee extends Employee {

	@Override
	public double calculate_salary() {
		float no_of_days,weages_per_day;
		double monthly_sal;
		System.out.println("Please enter no of days \n weages per day");
		no_of_days=sc.nextFloat();
		weages_per_day=sc.nextFloat();
		
		monthly_sal=no_of_days*weages_per_day;
		
		return monthly_sal;
		
	}

}
