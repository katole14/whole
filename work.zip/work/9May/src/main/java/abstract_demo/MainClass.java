package abstract_demo;

import java.util.Scanner;

/**
 * @author ckatole
 *
 */
public class MainClass {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	Employee emp=null;
	
	System.out.println("Please select option"+"\n 1 for Weeakly salary emp"+"\n 2 for monthly salary ");
	int choice=sc.nextInt();
	
	if(choice==1){
		
		emp=new WeeaklySalaryEmployee();
		emp.get_employee_details();
		emp.print_employee_details();
		
	}else if(choice==2){
		
		emp=new MonthlySalaryEmployee();
		emp.get_employee_details();
		emp.print_employee_details();
		
	}else{
		System.out.println("Invalid input");
		System.exit(0);
	}
	
	
}
}
