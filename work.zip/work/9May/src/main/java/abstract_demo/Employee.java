package abstract_demo;

import java.util.Scanner;

public abstract class Employee {
	int empid;
	String first_name, last_name;
	double salary;
	Scanner sc = new Scanner(System.in);

	public void get_employee_details() {

		System.out.println("Please enter\n emp id \n First_name \n Last_name");

		empid = sc.nextInt();
		first_name = sc.next();
		last_name = sc.next();

		
	}

	public void print_employee_details() {

		System.out.println("\nEmployee id" + empid + "\nFirstName" + first_name + "\nLastName" + last_name + "\nSalary"
				+ calculate_salary());

	}

	public abstract double calculate_salary();
}
