package abstract_demo;

public class WeeaklySalaryEmployee extends Employee{

	@Override
	public double calculate_salary() {
		float no_of_hours_perday,weages_per_hour;
		double weakly_sal;
		
		System.out.println("Please enter no of hours perday \n weages per hour");
		no_of_hours_perday=sc.nextFloat();
		weages_per_hour=sc.nextFloat();
		float per_day_sal=no_of_hours_perday*weages_per_hour;
		weakly_sal=per_day_sal*5;
		return weakly_sal;
	}
	
	
	
	

}
