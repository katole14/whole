package banking;

import java.util.Scanner;

public class UI_Class {
	
	
	public Account set_details(){
		
		Account account =new Account();
		boolean flag =false;
		Scanner sc=new Scanner(System.in);
		
		do{
		
		System.out.println("enter four digit Account Noof your choice");
		int acc_no=sc.nextInt();
		
		
		
		
		}while(!flag);
		
		
		
		
		
		
		return account;
	}
	

}
