package banking;

import java.util.Scanner;

public class RepositoryClass {
	
	
Account account[]=new Account[100];




}
