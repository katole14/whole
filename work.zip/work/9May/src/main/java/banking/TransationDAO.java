package banking;

public interface TransationDAO {

}
