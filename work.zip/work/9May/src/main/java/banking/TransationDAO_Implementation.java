package banking;

public class TransationDAO_Implementation implements TransationDAO{

}
