package banking;

import java.util.Date;



public class Account {
	int accNO;
	
	String fullName;
	Date openDate;
	String accType;
    double amount;
	public int getAccNO() {
		return accNO;
	}
	public void setAccNO(int accNO) {
		this.accNO = accNO;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Account [accNO=" + accNO + ", fullName=" + fullName + ", openDate=" + openDate + ", accType=" + accType
				+ ", amount=" + amount + "]";
	}
	
}
