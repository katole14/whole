package banking;

public class BootClass {

	public static void main(String[] args) {
		
	}

}
