package enum_demo;

import java.util.Scanner;

public class Employee {
	int empid;
	String first_name, last_name;
	double salary;
	WEEKDAYS emp_holiday;
	Scanner sc = new Scanner(System.in);

	public void get_emp_details() {

		System.out.println("Please give u r details");
		System.out.println("\nemployee is");
		System.out.println("\nFirstName");
		System.out.println("\nLastName");
		System.out.println("\nemployee holidays from below");

		empid = sc.nextInt();

		first_name = sc.next();

		last_name = sc.next();
		System.out.println("1 for Sunday"
				+"\n2 for Monday"
				+"\n3 for Tuesday"
				+"\n4for Wednesday"
				+"\n5 for Thrusday"
				+"\n6 for Friday"
				+"\n7 for Saturday");
		int choice=sc.nextInt();
		switch(choice){
		
		case 1: emp_holiday=WEEKDAYS.SUN;
		break;
		case 2: emp_holiday=WEEKDAYS.MON;
		break;
		case 3: emp_holiday=WEEKDAYS.TUE;
		break;
		case 4: emp_holiday=WEEKDAYS.WED;
		break;
		case 5: emp_holiday=WEEKDAYS.THR;
		break;
		case 6: emp_holiday=WEEKDAYS.FRI;
		break;
		case 7: emp_holiday=WEEKDAYS.SAT;
		break;
		
		
		
		
		
		}
	}
 
	
	public void print_details(){
		
		
		
		System.out.println("");
		
		
		
	}
}
