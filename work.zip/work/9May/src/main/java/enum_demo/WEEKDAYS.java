package enum_demo;

public enum WEEKDAYS {
	
	SUN,MON,TUE,WED,THR,FRI,SAT;

}
