package enum_demo;

public class MainClass {
	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.get_emp_details();
	}

}
