import java.util.HashSet;
import java.util.Iterator;

public class Demo_main {

public static void main(String[] args) {
	
	
	Employee emp1=new Employee("chai", "deep", 2003);
	Employee emp2=new Employee("jack", "jerry", 2004);
	Employee emp3=new Employee("sujit", "mishra", 3600);
	Employee emp4=new Employee("anish", "jaju", 3622.33);
	Employee emp5=new Employee("ankita", "paul", 5555);
	Employee emp6=new Employee("ankita", "paul", 5555);
	Employee emp7=new Employee("anish", "jaju", 3622.33);
	HashSet<Employee> employee= new HashSet();
	employee.add(emp1);
	employee.add(emp2);
	employee.add(emp3);
	employee.add(emp4);
	employee.add(emp5);
	employee.add(emp6);
	employee.add(emp7);
	
	
	Iterator<Employee> it=employee.iterator();
	while(it.hasNext())
		System.out.println(it.next());
	
	
}


}
