package taks;

public class Address {
	
	int doorNo;
	String stretName;
	String city;
	String state;
	public Address(){}
	
	public Address(int doorNo, String stretName, String city, String state) {
		super();
		this.doorNo = doorNo;
		this.stretName = stretName;
		this.city = city;
		this.state = state;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public String getStretName() {
		return stretName;
	}
	public void setStretName(String stretName) {
		this.stretName = stretName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", stretName=" + stretName + ", city=" + city + ", state=" + state + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + doorNo;
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((stretName == null) ? 0 : stretName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (doorNo != other.doorNo)
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (stretName == null) {
			if (other.stretName != null)
				return false;
		} else if (!stretName.equals(other.stretName))
			return false;
		return true;
	}
	

}
