package taks;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class MainClass {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);

	Account acc1=new Account(1, "Chaitanya", "saving", new Date(2016,02,16), 2000, new Address(7, "vinayaka", "chennai", "tamin nadu"));
	Account acc2=new Account(22, "tom", "Current", new Date(2016, 3, 12), 3666.0, new Address(8, "pavitra", "Pune", "maharashtra"));
	Account acc3=new Account(224, "shri", "saving", new Date(2016, 6, 14), 2145, new Address(9, "Hari", "Ranchi", "utter Pradesh"));
	Account acc4=new Account(332, "narendra", "current", new Date(2016, 7, 7), 5555, new Address(5, "vijay", "solapur", "maharashtra"));
	Account acc5=new Account(332, "narendra", "current", new Date(2016, 7, 7), 5555, new Address(5, "vijay", "solapur", "maharashtra"));
	Account acc6=new Account(22, "tom", "Current", new Date(2016, 3, 12), 3666.0, new Address(8, "pavitra", "Pune", "maharashtra"));
	HashSet<Account> setva=new HashSet<Account>();

	setva.add(acc1);
	setva.add(acc2);
	setva.add(acc3);
	setva.add(acc4);
	setva.add(acc5);
	setva.add(acc6);
	
	Iterator<Account> itr =setva.iterator();
	while(itr.hasNext()){
		
		Account acc=itr.next();
		System.out.println(acc);
		ArrayList<Account> al=new ArrayList<Account>();
		al.add(acc);
	}
	
	
	System.out.println("Emter your choice");
	System.out.println("1--sort by acc no");
	System.out.println("2--sort by date");
	System.out.println("3--sort by open date");
	int choice=sc.nextInt();
	
	switch(choice){
	
	case 1: Collections.sort(al, new SortByAccNo());
	
	
	
	
	
	
	
	}
	
}
}