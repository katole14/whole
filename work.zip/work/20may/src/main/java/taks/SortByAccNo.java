package taks;

import java.util.Comparator;

public class SortByAccNo implements Comparator<Account>{

	public int compare(Account o1, Account o2) {
		if((o1.getAccName().compareTo(o2.getAccName())>0))
			return 1;
	
	else if((o1.getAccName().compareTo(o2.getAccName())<0)){
		return -1;
		}
		return 0;
	}

}
